package org.learning.springlibrary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringLibraryApplicationTests {

	@Test
	void contextLoads() {
	}

}
